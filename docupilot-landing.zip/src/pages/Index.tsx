import Navbar from "@/components/landing/Navbar";
import HeroSection from "@/components/landing/HeroSection";
import ProblemSection from "@/components/landing/ProblemSection";
import HowItWorksSection from "@/components/landing/HowItWorksSection";
import OutputSection from "@/components/landing/OutputSection";
import RolesSection from "@/components/landing/RolesSection";
import DifferentiationSection from "@/components/landing/DifferentiationSection";
import DemoScenarioSection from "@/components/landing/DemoScenarioSection";
import CTASection from "@/components/landing/CTASection";
import Footer from "@/components/landing/Footer";

export default function Index() {
  return (
    <div className="min-h-screen bg-bg">
      <Navbar />
      <HeroSection />
      <ProblemSection />
      <HowItWorksSection />
      <OutputSection />
      <RolesSection />
      <DifferentiationSection />
      <DemoScenarioSection />
      <CTASection />
      <Footer />
    </div>
  );
}
