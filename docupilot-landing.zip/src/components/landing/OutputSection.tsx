import { motion } from "framer-motion";
import { FileCheck, HelpCircle, AlertCircle, Table, FileOutput } from "lucide-react";

const cards = [
  { icon: FileCheck, title: "Структурированный первый драфт", desc: "Документ уже собран по шаблону заказчика и разбит на логичные разделы." },
  { icon: HelpCircle, title: "Список открытых вопросов", desc: "Система показывает, чего не хватает для полноценного согласования и что нужно уточнить у заказчика." },
  { icon: AlertCircle, title: "Подсвеченные противоречия и пробелы", desc: "Слабые места видны до отправки документа, а не после замечаний." },
  { icon: Table, title: "Готовые таблицы и секции", desc: "Роли, требования, сценарии, ограничения и другие стандартные блоки формируются быстрее." },
  { icon: FileOutput, title: "Экспорт в рабочий формат", desc: "Документ можно выгрузить и использовать в реальном процессе, а не держать только внутри AI-интерфейса." },
];

const container = { hidden: {}, show: { transition: { staggerChildren: 0.05 } } };
const item = { hidden: { opacity: 0, y: 10 }, show: { opacity: 1, y: 0, transition: { duration: 0.4, ease: [0.16, 1, 0.3, 1] as const } } };

export default function OutputSection() {
  return (
    <section id="output" className="bg-surface-muted py-20 lg:py-28">
      <div className="mx-auto max-w-container px-6 lg:px-8">
        <p className="text-xs font-semibold uppercase tracking-wider text-brand">Результат</p>
        <h2 className="mt-2 text-balance text-3xl font-bold tracking-tight text-ink">
          Что получает команда на выходе
        </h2>
        <p className="mt-3 max-w-2xl text-pretty leading-relaxed text-text">
          Не просто сгенерированный текст, а рабочий черновик проектного документа, который можно дорабатывать и отправлять дальше по процессу.
        </p>

        <motion.div
          variants={container}
          initial="hidden"
          whileInView="show"
          viewport={{ once: true, amount: 0.2 }}
          className="mt-12 grid gap-4 sm:grid-cols-2 lg:grid-cols-3"
        >
          {cards.map((c) => (
            <motion.div
              key={c.title}
              variants={item}
              className="rounded-xl border border-line bg-surface p-6 shadow-dp-sm"
            >
              <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-brand-soft">
                <c.icon size={18} strokeWidth={1.5} className="text-brand" />
              </div>
              <h3 className="mt-4 text-sm font-semibold text-ink">{c.title}</h3>
              <p className="mt-1.5 text-sm leading-relaxed text-text">{c.desc}</p>
            </motion.div>
          ))}
        </motion.div>
      </div>
    </section>
  );
}
