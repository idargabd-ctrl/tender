import { useState } from "react";
import { Menu, X } from "lucide-react";

const navLinks = [
  { label: "Проблема", href: "#problem" },
  { label: "Как работает", href: "#how" },
  { label: "Что получаете", href: "#output" },
  { label: "Для кого", href: "#roles" },
  { label: "Демо", href: "#demo" },
];

export default function Navbar() {
  const [open, setOpen] = useState(false);

  return (
    <header className="sticky top-0 z-50 h-14 border-b border-line/60 bg-surface/80 backdrop-blur-md">
      <div className="mx-auto flex h-full max-w-container items-center justify-between px-6 lg:px-8">
        <a href="#" className="flex items-center gap-2">
          <div className="flex h-7 w-7 items-center justify-center rounded-md bg-brand">
            <span className="text-xs font-bold text-primary-foreground">D</span>
          </div>
          <span className="text-sm font-semibold text-ink">DocuPilot</span>
        </a>

        <nav className="hidden items-center gap-6 md:flex">
          {navLinks.map((l) => (
            <a
              key={l.href}
              href={l.href}
              className="text-sm font-medium text-text-muted transition-colors hover:text-ink"
            >
              {l.label}
            </a>
          ))}
        </nav>

        <div className="flex items-center gap-3">
          <a
            href="#cta"
            className="hidden h-9 items-center justify-center rounded-md bg-ink px-4 text-sm font-semibold text-surface transition-colors hover:bg-ink/90 md:inline-flex"
          >
            Запросить демо
          </a>
          <button
            className="inline-flex h-9 w-9 items-center justify-center rounded-md text-text-muted md:hidden"
            onClick={() => setOpen(!open)}
          >
            {open ? <X size={20} /> : <Menu size={20} />}
          </button>
        </div>
      </div>

      {open && (
        <div className="border-b border-line bg-surface px-6 py-4 md:hidden">
          <nav className="flex flex-col gap-3">
            {navLinks.map((l) => (
              <a
                key={l.href}
                href={l.href}
                className="text-sm font-medium text-text-muted"
                onClick={() => setOpen(false)}
              >
                {l.label}
              </a>
            ))}
            <a
              href="#cta"
              className="mt-2 inline-flex h-10 items-center justify-center rounded-md bg-ink text-sm font-semibold text-surface"
              onClick={() => setOpen(false)}
            >
              Запросить демо
            </a>
          </nav>
        </div>
      )}
    </header>
  );
}
