import { motion } from "framer-motion";
import { Briefcase, BarChart3, Cpu, Users } from "lucide-react";

const roles = [
  { icon: Briefcase, title: "Руководителю проекта", desc: "Быстрее получить первый драфт документа, сократить цикл до согласования и снизить тревогу из-за «сырой» документации." },
  { icon: BarChart3, title: "Бизнес-аналитику", desc: "Меньше ручной сборки, меньше копипасты и больше времени на смысловую проработку требований." },
  { icon: Cpu, title: "Системному аналитику", desc: "Удобнее структурировать роли, сценарии, ограничения, интеграции и зависимости в одном документе." },
  { icon: Users, title: "Руководителю практики / delivery lead", desc: "Единый стандарт документов по команде и меньше зависимости от нескольких сильных специалистов." },
];

const container = { hidden: {}, show: { transition: { staggerChildren: 0.06 } } };
const item = { hidden: { opacity: 0, y: 10 }, show: { opacity: 1, y: 0, transition: { duration: 0.4, ease: [0.16, 1, 0.3, 1] as const } } };

export default function RolesSection() {
  return (
    <section id="roles" className="py-20 lg:py-28">
      <div className="mx-auto max-w-container px-6 lg:px-8">
        <p className="text-xs font-semibold uppercase tracking-wider text-brand">Аудитория</p>
        <h2 className="mt-2 text-balance text-3xl font-bold tracking-tight text-ink">
          Кому подойдет DocuPilot
        </h2>
        <p className="mt-3 max-w-2xl text-pretty leading-relaxed text-text">
          Продукт создан для тех, кто отвечает не за «текст ради текста», а за управляемую проектную документацию.
        </p>

        <motion.div
          variants={container}
          initial="hidden"
          whileInView="show"
          viewport={{ once: true, amount: 0.2 }}
          className="mt-12 grid gap-4 sm:grid-cols-2"
        >
          {roles.map((r) => (
            <motion.div
              key={r.title}
              variants={item}
              className="rounded-xl border border-line bg-surface p-6 shadow-dp-sm"
            >
              <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-brand-soft">
                <r.icon size={20} strokeWidth={1.5} className="text-brand" />
              </div>
              <h3 className="mt-4 text-base font-semibold text-ink">{r.title}</h3>
              <p className="mt-1.5 text-sm leading-relaxed text-text">{r.desc}</p>
            </motion.div>
          ))}
        </motion.div>
      </div>
    </section>
  );
}
