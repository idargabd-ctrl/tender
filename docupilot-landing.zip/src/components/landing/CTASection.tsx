import { useState } from "react";
import { motion } from "framer-motion";

export default function CTASection() {
  const [form, setForm] = useState({ name: "", company: "", email: "", docType: "" });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // placeholder
    alert("Спасибо! Мы свяжемся с вами.");
  };

  return (
    <section id="cta" className="bg-surface-muted py-20 lg:py-28">
      <div className="mx-auto grid max-w-container gap-12 px-6 lg:grid-cols-2 lg:gap-16 lg:px-8">
        {/* Left */}
        <motion.div
          initial={{ opacity: 0, y: 12 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.5, ease: [0.16, 1, 0.3, 1] }}
          className="flex flex-col justify-center"
        >
          <h2 className="text-balance text-3xl font-bold tracking-tight text-ink lg:text-4xl">
            Покажем, как DocuPilot собирает документ на&nbsp;вашем реальном кейсе
          </h2>
          <p className="mt-4 max-w-md text-pretty leading-relaxed text-text">
            Оставьте заявку, и мы проведем демо на шаблоне ТЗ, ЧТЗ или постановки, с которыми работает ваша команда.
          </p>
          <p className="mt-6 text-xs text-text-muted">
            Подходит для integrator, delivery и analyst-команд
          </p>
        </motion.div>

        {/* Right — form */}
        <motion.form
          onSubmit={handleSubmit}
          initial={{ opacity: 0, y: 12 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.5, delay: 0.1, ease: [0.16, 1, 0.3, 1] }}
          className="rounded-xl border border-line bg-surface p-6 shadow-dp-md lg:p-8"
        >
          <div className="grid gap-5">
            {[
              { label: "Имя", name: "name" as const, type: "text", placeholder: "Как вас зовут" },
              { label: "Компания", name: "company" as const, type: "text", placeholder: "Название компании" },
              { label: "Рабочий email", name: "email" as const, type: "email", placeholder: "you@company.com" },
            ].map((f) => (
              <div key={f.name}>
                <label className="mb-1.5 block text-xs font-medium text-ink">{f.label}</label>
                <input
                  type={f.type}
                  required
                  placeholder={f.placeholder}
                  value={form[f.name]}
                  onChange={(e) => setForm({ ...form, [f.name]: e.target.value })}
                  className="h-11 w-full rounded-md border border-line bg-surface-muted px-4 text-sm text-ink outline-none transition-all placeholder:text-text-muted focus:border-brand focus:ring-2 focus:ring-brand/20"
                />
              </div>
            ))}

            <div>
              <label className="mb-1.5 block text-xs font-medium text-ink">Что вы хотите собирать?</label>
              <select
                required
                value={form.docType}
                onChange={(e) => setForm({ ...form, docType: e.target.value })}
                className="h-11 w-full rounded-md border border-line bg-surface-muted px-4 text-sm text-ink outline-none transition-all focus:border-brand focus:ring-2 focus:ring-brand/20"
              >
                <option value="">Выберите тип документа</option>
                <option value="tz">ТЗ</option>
                <option value="chtz">ЧТЗ</option>
                <option value="postanovki">Постановки</option>
                <option value="multi">Несколько типов документов</option>
              </select>
            </div>
          </div>

          <button
            type="submit"
            className="mt-6 inline-flex h-12 w-full items-center justify-center rounded-md bg-brand text-sm font-semibold text-primary-foreground shadow-dp-sm transition-all hover:bg-brand-hover hover:shadow-dp-md"
          >
            Запросить демо
          </button>
        </motion.form>
      </div>
    </section>
  );
}
