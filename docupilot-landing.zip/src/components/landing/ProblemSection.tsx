import { motion } from "framer-motion";
import { Shuffle, LayoutTemplate, Clock, Timer, AlertTriangle, UserX } from "lucide-react";

const cards = [
  { icon: Shuffle, title: "Требования разбросаны", desc: "Заметки, письма, созвоны, старые документы и скрины живут в разных местах, и аналитик собирает все вручную." },
  { icon: LayoutTemplate, title: "У каждого заказчика свой шаблон", desc: "Нужно не просто написать ТЗ, а попасть в структуру, терминологию и обязательные разделы конкретного клиента." },
  { icon: Clock, title: "Сильные аналитики тратят время на рутину", desc: "Вместо анализа и проработки решений они занимаются копипастой, сборкой секций и оформлением." },
  { icon: Timer, title: "Первый драфт появляется слишком поздно", desc: "Пока документ соберут и приведут в рабочий вид, проект уже теряет темп." },
  { icon: AlertTriangle, title: "Пробелы всплывают на согласовании", desc: "Отсутствующие ограничения, роли, сценарии и допущения замечают слишком поздно." },
  { icon: UserX, title: "Качество зависит от конкретного человека", desc: "Если сильный аналитик занят или уходит, качество документации резко проседает." },
];

const container = { hidden: {}, show: { transition: { staggerChildren: 0.06 } } };
const item = { hidden: { opacity: 0, y: 10 }, show: { opacity: 1, y: 0, transition: { duration: 0.4, ease: [0.16, 1, 0.3, 1] as const } } };

export default function ProblemSection() {
  return (
    <section id="problem" className="bg-surface-muted py-20 lg:py-28">
      <div className="mx-auto max-w-container px-6 lg:px-8">
        <p className="text-xs font-semibold uppercase tracking-wider text-brand">Проблема</p>
        <h2 className="mt-2 text-balance text-3xl font-bold tracking-tight text-ink">
          Почему подготовка проектных документов тормозит проект
        </h2>
        <p className="mt-3 max-w-2xl text-pretty leading-relaxed text-text">
          У большинства команд проблема не в том, что они не умеют писать документы. Проблема в том, что каждый раз приходится вручную собирать формальный артефакт из хаоса.
        </p>

        <motion.div
          variants={container}
          initial="hidden"
          whileInView="show"
          viewport={{ once: true, amount: 0.2 }}
          className="mt-12 grid gap-4 sm:grid-cols-2 lg:grid-cols-3"
        >
          {cards.map((c) => (
            <motion.div
              key={c.title}
              variants={item}
              className="rounded-xl border border-line bg-surface p-6 shadow-dp-sm transition-colors hover:bg-surface-muted/50"
            >
              <c.icon size={20} strokeWidth={1.5} className="text-text-muted" />
              <h3 className="mt-3 text-sm font-semibold text-ink">{c.title}</h3>
              <p className="mt-1.5 text-sm leading-relaxed text-text">{c.desc}</p>
            </motion.div>
          ))}
        </motion.div>
      </div>
    </section>
  );
}
