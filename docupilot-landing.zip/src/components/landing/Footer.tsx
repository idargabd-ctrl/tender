const links = [
  { label: "Проблема", href: "#problem" },
  { label: "Как работает", href: "#how" },
  { label: "Для кого", href: "#roles" },
  { label: "Демо", href: "#demo" },
];

export default function Footer() {
  return (
    <footer className="border-t border-line py-12">
      <div className="mx-auto flex max-w-container flex-col gap-8 px-6 sm:flex-row sm:items-start sm:justify-between lg:px-8">
        <div className="max-w-sm">
          <div className="flex items-center gap-2">
            <div className="flex h-7 w-7 items-center justify-center rounded-md bg-brand">
              <span className="text-xs font-bold text-primary-foreground">D</span>
            </div>
            <span className="text-sm font-semibold text-ink">DocuPilot</span>
          </div>
          <p className="mt-3 text-sm leading-relaxed text-text">
            AI-платформа подготовки проектных документов по шаблону заказчика для команд внедрения и разработки ПО.
          </p>
        </div>

        <div className="flex gap-12">
          <div>
            <p className="text-xs font-semibold uppercase tracking-wider text-text-muted">Навигация</p>
            <ul className="mt-3 space-y-2">
              {links.map((l) => (
                <li key={l.href}>
                  <a href={l.href} className="text-sm text-text transition-colors hover:text-ink">{l.label}</a>
                </li>
              ))}
            </ul>
          </div>
          <div>
            <p className="text-xs font-semibold uppercase tracking-wider text-text-muted">Контакты</p>
            <ul className="mt-3 space-y-2">
              <li><a href="mailto:hello@docupilot.ai" className="text-sm text-text transition-colors hover:text-ink">hello@docupilot.ai</a></li>
              <li><a href="#" className="text-sm text-text transition-colors hover:text-ink">Telegram</a></li>
              <li><a href="#" className="text-sm text-text transition-colors hover:text-ink">Политика конфиденциальности</a></li>
            </ul>
          </div>
        </div>
      </div>
      <div className="mx-auto mt-8 max-w-container px-6 lg:px-8">
        <p className="text-xs text-text-muted">© {new Date().getFullYear()} DocuPilot. Все права защищены.</p>
      </div>
    </footer>
  );
}
