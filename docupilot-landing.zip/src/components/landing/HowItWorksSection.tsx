import { motion } from "framer-motion";
import { Upload, FilePlus, LayoutList, Sparkles, Search, Download } from "lucide-react";

const steps = [
  { icon: Upload, num: "01", title: "Загрузите шаблон заказчика", desc: "Используйте существующий шаблон ТЗ, ЧТЗ или постановки, чтобы документ сразу строился в нужной структуре." },
  { icon: FilePlus, num: "02", title: "Добавьте исходные материалы", desc: "Заметки встреч, старые документы, текст требований, скрины интерфейса и описания доработок." },
  { icon: LayoutList, num: "03", title: "Получите skeleton документа", desc: "Система определит разделы, обязательные секции и покажет, где уже хватает данных, а где есть пробелы." },
  { icon: Sparkles, num: "04", title: "Сгенерируйте первый драфт", desc: "DocuPilot заполняет разделы, собирает таблицы и формирует документ в деловом, структурированном виде." },
  { icon: Search, num: "05", title: "Проверьте дыры и вопросы", desc: "Система выделяет недостающие данные, спорные места и формирует вопросы на уточнение." },
  { icon: Download, num: "06", title: "Доработайте и экспортируйте", desc: "Отредактируйте нужные секции и выгрузите документ в DOCX, PDF или Markdown." },
];

export default function HowItWorksSection() {
  return (
    <section id="how" className="py-20 lg:py-28">
      <div className="mx-auto max-w-container px-6 lg:px-8">
        <p className="text-xs font-semibold uppercase tracking-wider text-brand">Процесс</p>
        <h2 className="mt-2 text-balance text-3xl font-bold tracking-tight text-ink">
          Как это работает
        </h2>
        <p className="mt-3 max-w-2xl text-pretty leading-relaxed text-text">
          DocuPilot не пишет документ "из воздуха". Он собирает его по шаблону заказчика на основе ваших реальных материалов.
        </p>

        <div className="relative mt-14">
          {/* Vertical line */}
          <div className="absolute left-[19px] top-0 hidden h-full w-px bg-line lg:block" />

          <div className="grid gap-8 lg:gap-6">
            {steps.map((s, i) => (
              <motion.div
                key={s.num}
                initial={{ opacity: 0, y: 10 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.4, delay: i * 0.05, ease: [0.16, 1, 0.3, 1] }}
                className="flex gap-5 lg:gap-6"
              >
                <div className="relative z-10 flex h-10 w-10 shrink-0 items-center justify-center rounded-lg border border-line bg-surface shadow-dp-sm">
                  <s.icon size={18} strokeWidth={1.5} className="text-brand" />
                </div>
                <div className="pb-2">
                  <span className="font-mono text-xs tabular-nums text-text-muted">{s.num}</span>
                  <h3 className="mt-0.5 text-sm font-semibold text-ink">{s.title}</h3>
                  <p className="mt-1 max-w-lg text-sm leading-relaxed text-text">{s.desc}</p>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
