import { motion } from "framer-motion";
import { FileText, Layers, MessageSquareWarning } from "lucide-react";

const ease = [0.16, 1, 0.3, 1] as const;

export default function HeroSection() {
  return (
    <section className="py-20 lg:py-28">
      <div className="mx-auto grid max-w-container gap-12 px-6 lg:grid-cols-[55fr_45fr] lg:gap-16 lg:px-8">
        {/* Left */}
        <motion.div
          initial={{ opacity: 0, y: 16 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, ease }}
          className="flex flex-col justify-center"
        >
          <span className="mb-4 inline-flex w-fit items-center rounded-full bg-brand-soft px-3 py-1 text-xs font-medium text-brand">
            Для delivery-команд и аналитиков
          </span>

          <h1 className="text-balance text-4xl font-bold leading-[1.1] tracking-tight text-ink lg:text-5xl">
            Собирайте ТЗ, ЧТЗ и&nbsp;постановки по&nbsp;шаблону заказчика — из&nbsp;заметок, старых документов и&nbsp;сырых требований
          </h1>

          <p className="mt-5 max-w-xl text-pretty leading-relaxed text-text">
            DocuPilot помогает РП, бизнес- и&nbsp;системным аналитикам быстрее готовить первый драфт проектных документов: со&nbsp;структурой, обязательными разделами, вопросами на&nbsp;уточнение и&nbsp;экспортом в&nbsp;рабочий формат.
          </p>

          <div className="mt-8 flex flex-col gap-3 sm:flex-row sm:items-center">
            <a
              href="#cta"
              className="inline-flex h-12 items-center justify-center rounded-md bg-brand px-5 text-sm font-semibold text-primary-foreground shadow-dp-sm transition-all hover:bg-brand-hover hover:shadow-dp-md"
            >
              Запросить демо
            </a>
            <a
              href="#how"
              className="inline-flex h-12 items-center justify-center rounded-md border border-line bg-surface px-5 text-sm font-semibold text-ink transition-all hover:border-line-strong hover:bg-surface-muted"
            >
              Посмотреть, как это работает
            </a>
          </div>

          <p className="mt-4 text-xs text-text-muted">
            Для команд внедрения и заказной разработки ПО
          </p>
        </motion.div>

        {/* Right — Workbench mockup */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.15, ease }}
          className="relative"
        >
          <div className="rounded-xl border border-line bg-surface shadow-dp-lg">
            {/* Top bar */}
            <div className="flex items-center gap-2 border-b border-line px-4 py-2.5">
              <div className="h-2.5 w-2.5 rounded-full bg-line-strong" />
              <div className="h-2.5 w-2.5 rounded-full bg-line-strong" />
              <div className="h-2.5 w-2.5 rounded-full bg-line-strong" />
              <span className="ml-3 text-[11px] font-medium text-text-muted">DocuPilot — Новый документ</span>
            </div>
            {/* Body grid */}
            <div className="grid grid-cols-3 divide-x divide-line">
              {/* Template pane */}
              <div className="p-4">
                <div className="mb-3 flex items-center gap-1.5">
                  <FileText size={14} className="text-brand" />
                  <span className="text-[11px] font-semibold text-ink">Шаблон ЧТЗ заказчика</span>
                </div>
                <div className="space-y-2">
                  {["1. Общие сведения", "2. Назначение", "3. Требования", "4. Ограничения", "5. Роли"].map((s) => (
                    <div key={s} className="rounded bg-surface-muted px-2 py-1.5 text-[10px] text-text">{s}</div>
                  ))}
                </div>
              </div>
              {/* Sources pane */}
              <div className="p-4">
                <div className="mb-3 flex items-center gap-1.5">
                  <Layers size={14} className="text-brand" />
                  <span className="text-[11px] font-semibold text-ink">Источники</span>
                </div>
                <div className="space-y-2">
                  {["Заметки встречи 12.03", "Старое ТЗ v2.1", "Скрины интерфейса", "Email от заказчика"].map((s) => (
                    <div key={s} className="rounded border border-line px-2 py-1.5 text-[10px] text-text">{s}</div>
                  ))}
                </div>
              </div>
              {/* Generated pane */}
              <div className="p-4">
                <div className="mb-3 flex items-center gap-1.5">
                  <FileText size={14} className="text-success" />
                  <span className="text-[11px] font-semibold text-ink">Документ</span>
                </div>
                <div className="space-y-2">
                  <div className="rounded bg-brand-soft px-2 py-1.5 text-[10px] text-brand">✓ Общие сведения</div>
                  <div className="rounded bg-brand-soft px-2 py-1.5 text-[10px] text-brand">✓ Назначение</div>
                  <div className="rounded bg-brand-soft px-2 py-1.5 text-[10px] text-brand">✓ Требования</div>
                  <div className="flex items-center gap-1 rounded bg-warning-soft px-2 py-1.5 text-[10px] text-warning">
                    <MessageSquareWarning size={10} />
                    <span>2 вопроса</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </motion.div>
      </div>
    </section>
  );
}
