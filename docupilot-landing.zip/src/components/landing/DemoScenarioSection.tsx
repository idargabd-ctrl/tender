import { motion } from "framer-motion";
import { FileUp, Paperclip, FileText, Send } from "lucide-react";

const steps = [
  { icon: FileUp, num: "1", title: "Берете шаблон клиента", desc: "Загружаете структуру документа, которую уже принимает заказчик." },
  { icon: Paperclip, num: "2", title: "Добавляете материалы", desc: "Подгружаете заметки встречи, описание доработки, старое ТЗ и скрины интерфейса." },
  { icon: FileText, num: "3", title: "Получаете первый драфт", desc: "DocuPilot собирает разделы, формирует текст и показывает, какие данные нужно уточнить." },
  { icon: Send, num: "4", title: "Дорабатываете и отправляете", desc: "Вы редактируете нужные блоки и экспортируете документ в рабочий формат." },
];

export default function DemoScenarioSection() {
  return (
    <section id="demo" className="py-20 lg:py-28">
      <div className="mx-auto max-w-5xl px-6 lg:px-8">
        <p className="text-xs font-semibold uppercase tracking-wider text-brand">Кейс</p>
        <h2 className="mt-2 text-balance text-3xl font-bold tracking-tight text-ink">
          Как выглядит работа в реальном кейсе
        </h2>
        <p className="mt-3 max-w-2xl text-pretty leading-relaxed text-text">
          Например, вам нужно подготовить ЧТЗ на доработку модуля по шаблону заказчика.
        </p>

        <div className="mt-12 rounded-xl border border-line bg-surface p-6 shadow-dp-md lg:p-10">
          {/* Timeline */}
          <div className="grid gap-8 sm:grid-cols-2 lg:grid-cols-4">
            {steps.map((s, i) => (
              <motion.div
                key={s.num}
                initial={{ opacity: 0, y: 10 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.4, delay: i * 0.08, ease: [0.16, 1, 0.3, 1] }}
              >
                <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-brand-soft">
                  <s.icon size={18} strokeWidth={1.5} className="text-brand" />
                </div>
                <span className="mt-3 block font-mono text-xs tabular-nums text-text-muted">Этап {s.num}</span>
                <h3 className="mt-1 text-sm font-semibold text-ink">{s.title}</h3>
                <p className="mt-1 text-sm leading-relaxed text-text">{s.desc}</p>
              </motion.div>
            ))}
          </div>

          <div className="mt-10 flex justify-center">
            <a
              href="#cta"
              className="inline-flex h-12 items-center justify-center rounded-md bg-brand px-8 text-sm font-semibold text-primary-foreground shadow-dp-sm transition-all hover:bg-brand-hover hover:shadow-dp-md"
            >
              Запросить демо на моем шаблоне
            </a>
          </div>
        </div>
      </div>
    </section>
  );
}
