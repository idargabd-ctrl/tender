import { motion } from "framer-motion";
import { Check } from "lucide-react";

const points = [
  { title: "Работа по шаблону заказчика", desc: "Документ строится не с чистого листа, а по реальной структуре, принятой у клиента." },
  { title: "Генерация по секциям", desc: "Вы управляете отдельными разделами, а не получаете одно большое полотно текста." },
  { title: "Подсветка дыр и противоречий", desc: "Система показывает, чего не хватает и где документ слабый, вместо того чтобы делать вид, что «все поняла»." },
  { title: "Опора на исходные материалы", desc: "Контент собирается из ваших заметок, старых документов, скринов и требований, а не выдумывается заново." },
  { title: "Рабочий экспорт", desc: "Результат можно выгрузить и использовать в реальном проектном процессе." },
];

export default function DifferentiationSection() {
  return (
    <section className="bg-surface-muted py-20 lg:py-28">
      <div className="mx-auto max-w-container px-6 lg:px-8">
        <p className="text-xs font-semibold uppercase tracking-wider text-brand">Отличия</p>
        <h2 className="mt-2 text-balance text-3xl font-bold tracking-tight text-ink">
          Почему DocuPilot — это не просто ещё один AI-генератор
        </h2>
        <p className="mt-3 max-w-2xl text-pretty leading-relaxed text-text">
          Обычные AI-инструменты пишут текст. DocuPilot помогает собирать формальный проектный документ так, как его реально ждут в delivery-процессе.
        </p>

        <div className="mt-12 grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
          {points.map((p, i) => (
            <motion.div
              key={p.title}
              initial={{ opacity: 0, y: 10 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.4, delay: i * 0.05, ease: [0.16, 1, 0.3, 1] }}
              className="rounded-xl border border-line bg-brand-soft/40 p-5"
            >
              <div className="flex items-start gap-3">
                <div className="mt-0.5 flex h-5 w-5 shrink-0 items-center justify-center rounded-full bg-brand">
                  <Check size={12} strokeWidth={2.5} className="text-primary-foreground" />
                </div>
                <div>
                  <h3 className="text-sm font-semibold text-ink">{p.title}</h3>
                  <p className="mt-1 text-sm leading-relaxed text-text">{p.desc}</p>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
